function drawPipe() {
    

}
