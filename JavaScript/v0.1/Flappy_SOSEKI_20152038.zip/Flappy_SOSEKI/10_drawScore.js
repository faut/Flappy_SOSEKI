function drawScore() {
    // スコアを表示するラベルを作成
    var scoreLabel = new Label("SCORE : 0");
    scoreLabel.font = "16px Tahoma";
    scoreLabel.color = "red";
    scoreLabel.x = 10; // X座標
    scoreLabel.y = 5; // Y座標
}
