function gameOver() {
    var timecount = 0
        ;

    resetVariable();
}
