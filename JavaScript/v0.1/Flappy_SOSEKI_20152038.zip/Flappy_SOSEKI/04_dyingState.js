function dyingState() {
    var timecount = 0
        ;
}
