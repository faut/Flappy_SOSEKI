function startMenu() {
    var timeCount = 0
        ;
}
