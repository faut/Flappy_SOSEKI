function resetVariable() {

}
