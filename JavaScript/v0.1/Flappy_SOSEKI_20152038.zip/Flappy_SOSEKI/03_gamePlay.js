function gamePlay() {
    var timeCount = 0
        ;



}
